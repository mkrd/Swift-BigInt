/*
	————————————————————————————————————————————————————————————————————————————
	MG Complex
	————————————————————————————————————————————————————————————————————————————
	Created by Marcel Kröker on 06.11.16.
	Copyright (c) 2016 Blubyte. All rights reserved.
*/

import Foundation

public struct Complex
{
	var (re, im): (Double, Double)

	init(re: Double, im: Double)
	{
		self.re = re
		self.im = im

	}

	init(re: Double)
	{
		self.re = re
		self.im = 0.0
	}

	init(i: Double)
	{
		self.re = 0.0
		self.im = i
	}

	var r: Double
	{
		get
		{
			return self.re
		}
		set
		{
			self.re = r
		}
	}

	var i: Double
		{
		get
		{
			return self.im
		}
		set
		{
			self.im = i
		}
	}
}

public func +(lhs: Complex, rhs: Complex) -> Complex
{
	return Complex(
		re: lhs.re + rhs.re,
		im: lhs.im + rhs.im
	)
}

public func -(lhs: Complex, rhs: Complex) -> Complex
{
	return Complex(
		re: lhs.re + rhs.re,
		im: lhs.im + rhs.im
	)
}

public func *(lhs: Complex, rhs: Complex) -> Complex
{
	let (a, b, c, d) = (lhs.re, lhs.im, rhs.re, rhs.im)

	return Complex(
		re: a * c - b * d,
		im: b * c + a * d
	)
}

public func /(lhs: Complex, rhs: Complex) -> Complex
{
	let (a, b, c, d) = (lhs.re, lhs.im, rhs.re, rhs.im)

	return Complex(
		re: (a * c + b * d) / (c * c + d * d),
		im: (b * c - a * d) / (c * c + d * d)
	)
}

public func exp(_ x: Complex) -> Complex
{
	let (a, b) = (x.re, x.im)

	let ea = Complex(re: pow(2.7, a))
	let t = Complex(re: cos(b), im: sin(b))

	return ea * t
}

