/*
	————————————————————————————————————————————————————————————————————————————
	MG Storage.swift
	————————————————————————————————————————————————————————————————————————————
	Created by Marcel Kröker on 09.10.16.
	Copyright (c) 2016 Blubyte. All rights reserved.
*/

import Foundation

private let ud = UserDefaults.standard

public struct Storage
{
	static func write(_ value: Any?, forKey key: String)
	{
		ud.set(value, forKey: key)
		ud.synchronize()
	}

	static func read(forkey key: String) -> Any?
	{
		return ud.object(forKey: key)
	}

	static func remove(forKey key: String)
	{
		ud.removeObject(forKey: key)
	}

	static func printData()
	{
		print(ud.dictionaryRepresentation())
	}
}
