import Foundation

//benchmarkPrint(title: "BInt tests")
//{
//	//testBaseConversionRandom(iterations: 10_000, maxStringSize: 999)
//	testBIntRandom(iterations: 1_000)
//	testBInt()
//}
//
//benchmarkBInt()


extension String
{
	mutating func removeSubrange(_ bounds: CountableClosedRange<Int>)
	{
		let start = self.index(self.startIndex, offsetBy: bounds.lowerBound)
		let end   = self.index(self.startIndex, offsetBy: bounds.upperBound)
		self.removeSubrange(start...end)
	}

	mutating func removeSubrange(_ bounds: CountableRange<Int>)
	{
		let start = self.index(self.startIndex, offsetBy: bounds.lowerBound)
		let end   = self.index(self.startIndex, offsetBy: bounds.upperBound)
		self.removeSubrange(start..<end)
	}


	mutating func popLine() -> String
	{
		if let i = self["\n"]
		{
			let line = self[0..<i]

			self.removeSubrange(0...i)
			return line
		}
		return ""
	}

}


func loadFileContent(from: FileManager.SearchPathDirectory, name:  String) -> String
{
	let dir = FileManager.default.urls(for: from, in: .userDomainMask).first!
	let path = dir.appendingPathComponent(name)
	let text = try? String(contentsOf: path, encoding: String.Encoding.utf8) 
	return text ?? ""
}

struct VideoDistributer
{
	var videoCount,
		endpointCount,
		requestCount,
		cacheCount,
		cacheSize: Int

	var videoSizes = [Int]()

	var latencies: Matrix<Int>
	var dci = 0 // data center index

	var videoRequests: Matrix<Int>

	init(_ file: String)
	{
		var lines = file.components(separatedBy: "\n")
		lines.removeLast()

		let inputData = lines.map{
			$0.components(separatedBy: " ").map{ Int($0)! }
		}

		self.videoCount    = inputData[0][0]
		self.endpointCount = inputData[0][1]
		self.requestCount  = inputData[0][2]
		self.cacheCount    = inputData[0][3]
		self.cacheSize     = inputData[0][4]

		self.latencies = Matrix<Int>( // row: endpoint, column: datacenter, cache server
			repeating: -1, // -1 means there is no connection
			rows: self.endpointCount,
			cols: self.cacheCount + 1 // last column for data center
		)


		self.videoRequests = Matrix<Int>( // row: endpoint, column: video
			repeating: -1, // -1 means there is no video request
			rows: self.endpointCount,
			cols: self.videoCount
		)

		self.dci = self.cacheCount

		for i in 0..<self.videoCount
		{
			self.videoSizes.append(inputData[1][i])
		}

		var kOffset = 0
		for i in 0..<self.endpointCount
		{
			// index of current endpoint description index
			let j = i + kOffset + 2

			// set data center latencies for endpoint i
			self.latencies[i, self.dci] = inputData[j][0]

			// number of connections of endpoint i
			let connections = inputData[j][1]

			// set cache server latencies for endpoint i

			if connections > 0
			{
				for k in 1...connections
				{
					let cacheServerID = inputData[j + k][0]
					let cacheServerLatency = inputData[j + k][1]

					self.latencies[i, cacheServerID] = cacheServerLatency
				}

				kOffset += connections
			}
		}

		for i in 0..<self.requestCount
		{
			// total offset in input data
			let j = i + kOffset + self.endpointCount + 2

			let videoID = inputData[j][0]
			let endpointID = inputData[j][1]
			let requests = inputData[j][2]

			self.videoRequests[endpointID, videoID] = requests
		}

		//print(file)
	}
}


//var vd = VideoDistributer(
//	loadFileContent(from: .downloadsDirectory, name: "me_at_the_zoo.txt")
//)

//var vd = VideoDistributer(
//	loadFileContent(from: .downloadsDirectory, name: "videos_worth_spreading.txt")
//)

//var vd = VideoDistributer(
//	loadFileContent(from: .downloadsDirectory, name: "trending_today.txt")
//)

var vd = VideoDistributer(
	loadFileContent(from: .downloadsDirectory, name: "kittens.txt")
)






// cache per row, videos per column
var resultDistribution = [[Int]](repeating: [Int](), count: vd.cacheCount)

var remainingCache = [Int](repeating: vd.cacheSize, count: vd.cacheSize)





// endpoint per row, video importance per column
var videoPriority = [[(videoID: Int, priority: Int)]](repeating: [(Int, Int)](), count: vd.endpointCount)

for (endpoint, videoID) in vd.videoRequests
	where vd.videoRequests[endpoint, videoID] != -1
{
	let requests = vd.videoRequests[endpoint, videoID]
	let size = vd.videoSizes[videoID]

	videoPriority[endpoint].append((videoID, requests * size))
}

for i in 0..<videoPriority.count
{
	videoPriority[i].sort(by: { $0.priority > $1.priority })
}






//print(videoPriority)

// endpoint per row, latency per row
var bestServersPerEndpoint = [[(cacheID: Int, latency: Int)]](repeating: [(Int, Int)](), count: vd.endpointCount)

for (endpoint, server) in vd.latencies
	where vd.latencies[endpoint, server] != -1
{
	let latency = vd.latencies[endpoint, server]

	bestServersPerEndpoint[endpoint].append(((endpoint, latency)))
}

for i in 0..<bestServersPerEndpoint.count
{
	bestServersPerEndpoint[i].sort(by: { $0.latency < $1.latency })
}





for endpoint in (0..<vd.endpointCount).reversed()
{
	for (videoID, videoPriority) in videoPriority[endpoint]
	{
		for (cacheID, latency) in bestServersPerEndpoint[endpoint]
		{
			if cacheID >= 0 && cacheID < vd.cacheCount
			{
				if !resultDistribution[cacheID].contains(videoID)
				{
					if vd.videoSizes[videoID] <= remainingCache[cacheID]
					{
						resultDistribution[cacheID].append(videoID)
						remainingCache[cacheID] -= vd.videoSizes[videoID]
					}
				}
			}
		}
	}
}

// Filter maps to data center and remove empty caches
for i in 0..<resultDistribution.count
{
	resultDistribution[i] = resultDistribution[i].filter({ $0 != vd.dci })
}
resultDistribution = resultDistribution.filter({ $0 != []})


// Print the result
print(resultDistribution.count)
for i in 0..<resultDistribution.count
{
	var prnt = "\(i)"
	for j in 0..<resultDistribution[i].count
	{
		prnt += " \(resultDistribution[i][j])"
	}
	print(prnt)
}
